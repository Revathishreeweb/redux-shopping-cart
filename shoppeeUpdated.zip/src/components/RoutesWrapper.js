import React from 'react'
import { BrowserRouter,Routes,Route } from 'react-router-dom'
import CartDetails from './CartDetails'
import Gallery from './Gallery'
import Checkout from './Checkout'

const RoutesWrapper = () => {
  return (
    <>
    <BrowserRouter>
    <Routes>
        <Route path='/' element={<Gallery/>}/>
        <Route path='/cartDetails' element={<CartDetails/>}/>
        <Route path='/checkout' element={<Checkout/>}/>
    </Routes>
    </BrowserRouter>
    </>
  )
}

export default RoutesWrapper