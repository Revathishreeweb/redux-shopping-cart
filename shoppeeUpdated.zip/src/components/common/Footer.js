import React from 'react'

const Footer = () => {
  return (
    <div className='text-center bg-dark text-white'>Copyrights © Colan Infotech</div>
  )
}

export default Footer