import React, { useEffect, useState } from 'react'
import {useNavigate } from 'react-router-dom'
import Layout from './common/Layout';
import { useSelector,useDispatch } from 'react-redux';


const CartDetails = () => {
  const [totalPriceAmount,setTotalPriceAmount]=useState(0);
  const navigate=useNavigate();
  const cart=useSelector((state)=>state);
  const dispatch=useDispatch()

 
   const totalPrice=cart.reduce((acc,curr)=>{
    return acc+curr.price*curr.quantity
  },0)
  useEffect(()=>{
    setTotalPriceAmount(totalPrice)

  },[totalPrice]);


  const handleCheckout=()=>{
    if(totalPrice>0){
      navigate('/checkout')
    }

  }
  return (
    <>
<Layout>
    
<div className='container'>
            <div className='row'>
               <div className='col-8'>
                <div className='row'>
                <div className='col-12'>
                {cart.length?(cart.map((item)=>{
                    return(
                      <>
                    <div className='card p-3 mb-2' key={item.id}>
                      <div className='wrapper d-flex justify-content-between'>
                        <div className='left-side'>
                        <div className='img-wrapper'>
                          <div className='img-wrapper'>
                          <img src={require(`../images/${item.image}`)} alt='products'/>
                          </div>
                         </div>
                         <div className='text-bold'>{item.title}</div>
                         <div>{item.description}</div>
                         <div className='text-bold'>Price: {item.price}</div>
                         <div className='text-bold'>Total price: {item.price*item.quantity}</div>
                        </div>
                       
                      <div className='right-side'>
                      <h6 className='Quantity'>Quantity</h6>
                       <div className='quantity-adjust d-flex align-items-center'>
                       <button className='btn btn-warning' onClick={()=>{dispatch({type:"INCREASE",payload:item})}}>+</button>
                       <div className='mx-2'>{item.quantity}</div>
                        <button className='btn btn-warning' onClick={()=>{
                          if(item.quantity>1)
                          {
                            dispatch({type:"DECREASE",payload:item})
                        }
                        else{
                          dispatch({type:"REMOVE",payload:item})
                        }
                      }}
                          >-</button>
                       </div>
                       <button className='btn btn-danger' onClick={()=>{dispatch({type:"REMOVE",payload:item})}}>Delete</button>
                      </div>
                      </div>
                    </div>
                    </>
                )
              })):(<h6>No products Added</h6>)}
                </div>
               
                </div>
               </div>
               <div className='col-4'>
               
                    <div className='card proceed-to-checkout' >
                        <div>Total price:{totalPriceAmount}</div>
                   <button className='btn btn-success' onClick={handleCheckout}>Proceed to checkout</button>
                    </div>
            
               </div>
            </div>
        </div>
</Layout>
    
    
    </>
  )
}

export default CartDetails