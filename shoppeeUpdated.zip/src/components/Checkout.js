import React from 'react'
import Layout from './common/Layout'

const Checkout = () => {
  return (
    <>
    <Layout>
    <div className='order'>Thank you!Your Order has been placed</div>
    </Layout>
    </>
  )
}

export default Checkout