
  export const products= [
    {            
        price:"100",
        image:"belt.png",
        coupons:"TRYNEW",
        title:"T-TRACK Sneakers For Men",
        description:"Cotton material",
        id:1
    },
    {            
        price:"200",
        image:"wallet.png",
        coupons:"TRYNEW",
       title:"Go Run Fast-Quake Running Shoes For Men  (Navy)",
       description:"sneakers",
        id:2
    },
    {            
        price:"20100",
        image:"pouch.png",
        coupons:"TRYNEW",
        title:"mobile phones",
        description:"poco",
        id:3
    },
    {            
        price:"1100",
        image:"shoes.png",
        coupons:"TRYNEW",
        title:"speakers",
        description:"branded",
        id:4
    },
    {            
        price:"1500",
        image:"leather.png",
        coupons:"TRYNEW",
        title:"monitors",
        description:"branded",
        id:5
    },
    {            
        price:"1100",
        image:"belt.png",
        coupons:"TRYNEW",
        title:"keyboard",
        description:"branded",
        id:6
    }
    
]
