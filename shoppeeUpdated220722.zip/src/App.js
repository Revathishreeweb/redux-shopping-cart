import logo from './logo.svg';
import './App.css';
import RoutesWrapper from './components/RoutesWrapper';

function App() {
  return (
    <div className="App">
      <RoutesWrapper/>
    </div>
  );
}

export default App;
