
  export const products= [
    {            
        price:"100",
        image:"aloevera-gel.png",
        coupons:"TRYNEW",
        title:"Aloevera Gel",
        description:"Cotton material",
        id:1,
        status:'Trending'
    },
    {            
        price:"200",
        image:"bringa-hair-oil.png",
        coupons:"TRYNEW",
       title:"bringa hair oil",
       description:"sneakers",
        id:2,
        status:'Assured'
    },
    {            
        price:"20100",
        image:"face-cream.png",
        coupons:"TRYNEW",
        title:"face cream",
        description:"poco",
        id:3,
        status:'10% Off'
    },
    {            
        price:"1100",
        image:"herbal-tea.png",
        coupons:"TRYNEW",
        title:"Herbal Tea",
        description:"branded",
        id:4,
        status:'Popular'
    },
    {            
        price:"1500",
        image:"kumkumadi.png",
        coupons:"TRYNEW",
        title:"Kumkumadi",
        description:"branded",
        id:5,
        status:'20% Off'
    },
    {            
        price:"1100",
        image:"shampoo.png",
        coupons:"TRYNEW",
        title:"Shampoo",
        description:"branded",
        id:6,
        status:'Assured'
    }
    
]
